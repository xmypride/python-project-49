### Hexlet tests and linter status:
[![Actions Status](https://github.com/xmypride/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/xmypride/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/8f1c0374d8808c85cb9a/maintainability)](https://codeclimate.com/github/xmypride/python-project-49/maintainability)
