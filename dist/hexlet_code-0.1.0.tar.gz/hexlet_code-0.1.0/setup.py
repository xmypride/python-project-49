# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/xmypride/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/xmypride/python-project-49/actions)\n\n[![Maintainability](https://api.codeclimate.com/v1/badges/8f1c0374d8808c85cb9a/maintainability)](https://codeclimate.com/github/xmypride/python-project-49/maintainability)\n\n\nThis project was built using Poetry (https://python-poetry.org/)\n\n\nInstall:\n\ngit clone https://github.com/xmypride/python-project-49.git\n\ncd python-project-49\n\nmake package-install\n\n\nGames:\n\nEven number \n[![brain-even](https://asciinema.org/a/562450.svg)](https://asciinema.org/a/562450)\n\nCalculate the expression\n[![brain-calc](https://asciinema.org/a/562607.svg)](https://asciinema.org/a/562607)\n\nGreatest common divisor\n[![brain-gcd](https://asciinema.org/a/562612.svg)](https://asciinema.org/a/562612)\n\nGuess missing number\n[![brain-progression](https://asciinema.org/a/562627.svg)](https://asciinema.org/a/562627)\n\nPrime number\n[![brain-prime](https://asciinema.org/a/562631.svg)](https://asciinema.org/a/562631)\n\n',
    'author': 'xmypride',
    'author_email': 'x.my-pride.x@yandex.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
